﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVC_ANIMAL_ODEV_HMZ.Models
{
    public class Pet
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Hayvan Adı Boş Bırakılamaz")]
        public string? Name { get; set; }
        [DataType(DataType.Upload)]
        public byte[]? Photo { get; set; }
        [NotMapped]
        [DisplayName("Image")]
        public IFormFile? PhotoData { get; set;}
    }
}
