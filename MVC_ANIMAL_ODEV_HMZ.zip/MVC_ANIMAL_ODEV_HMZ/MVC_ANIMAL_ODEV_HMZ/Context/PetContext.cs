﻿using Microsoft.EntityFrameworkCore;
using MVC_ANIMAL_ODEV_HMZ.Models;

namespace MVC_ANIMAL_ODEV_HMZ.Context
{
    public class PetContext : DbContext
    {
        public PetContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Pet> Pets { get; set; }
    }
}
